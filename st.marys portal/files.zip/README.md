# St. Mary’s RC JHS Student Portal

A full-stack web application for St. Mary’s RC JHS, where students can register, view exam results, and admins can manage results and users.

## Features

- Student registration & login
- Admin registration & login (first admin only, then disable route)
- Secure JWT authentication
- Students can view their own results
- Admins can add/update results for any student
- Admins can manage users (disable/enable/reset password)
- Password reset with email link
- Email notifications when results are updated
- User profile management
- (Optional) Audit logging

---

## Project Structure

```
stmarys-portal/
  backend/
    models/
    routes/
    server.js
    package.json
    .env.example
  frontend/
    src/
      pages/
      App.tsx
      App.css
      index.tsx
    public/
      index.html
    package.json
    tsconfig.json
```

---

## 1. Getting Started

### Prerequisites

- Node.js & npm
- MongoDB (local or [MongoDB Atlas](https://www.mongodb.com/atlas))
- (Recommended) GitHub account

---

### 2. Setup & Run Locally

#### 2.1. Clone the repo

```sh
git clone https://github.com/<your-username>/stmarys-portal.git
cd stmarys-portal
```

#### 2.2. Backend Setup

```sh
cd backend
cp .env.example .env
# Edit .env to use your own MongoDB URI and email credentials
npm install
npm start
```

- This runs your backend server on port 5000 by default.

#### 2.3. Frontend Setup

```sh
cd ../frontend
npm install
npm start
```

- This runs your React frontend on port 3000 by default.

#### 2.4. First Admin Registration

- Use the `/api/auth/admin-signup` endpoint (or build a simple React form) to create your first admin account.
- **After first use, disable or remove this endpoint for security.**

---

## 3. Deployment Guide

### Recommended Stack

- **Backend:** [Render](https://render.com), [Railway](https://railway.app), [Heroku](https://heroku.com)
- **Frontend:** [Vercel](https://vercel.com), [Netlify](https://netlify.com)
- **Database:** [MongoDB Atlas](https://www.mongodb.com/atlas)

### 3.1. Prepare Environment Variables

- Update `backend/.env` for production:
  ```
  MONGO_URI=your-mongodb-atlas-uri
  JWT_SECRET=your-very-strong-secret
  EMAIL_USER=your_email@gmail.com
  EMAIL_PASS=your_gmail_app_password
  CORS_ORIGIN=https://your-frontend-url.vercel.app
  ```
- In `frontend/.env` (create if missing):
  ```
  REACT_APP_API_URL=https://your-backend-url.onrender.com
  ```

### 3.2. Deploy Backend

1. Push your code to GitHub.
2. Create a new Web Service on [Render](https://render.com/) (or similar):
    - Point to `backend/` directory.
    - Set environment variables.
    - Build command: `npm install`
    - Start command: `npm start`
3. Copy the public backend URL.

### 3.3. Deploy Frontend

1. Go to [Vercel](https://vercel.com/) or [Netlify](https://netlify.com/).
2. Import your GitHub repo/project.
3. Set project root to `frontend/` and set the environment variable `REACT_APP_API_URL`.
4. Deploy and get your public frontend URL.

### 3.4. Final Setup

- **CORS**: Make sure your backend allows requests from your frontend URL.
- **Emails**: Use a real SMTP config in production.

---

## 4. Extra Features

- **Password Reset:** Users can request a reset link via email.
- **Email Notifications:** Students are notified when results are updated.
- **User Profile:** Students can view/update their profile.
- **Admin User Management:** Disable/enable users, reset passwords.
- **Audit Trail (Optional):** Log all admin actions for security.

---

## 5. Custom Domain & HTTPS

- Both Vercel and Netlify allow you to use a custom domain and handle HTTPS automatically.

---

## 6. How to Use

- Students sign up and log in to view their results.
- Admins log in to manage student results and users via the `/admin` and `/admin-users` pages.
- Password reset and profile management available from the web portal.
- All changes are secured and logged.

---

## 7. Troubleshooting

- **Emails not sending:** Check SMTP credentials and provider limits.
- **Build/deploy issues:** Check logs on Render/Vercel/Netlify.
- **CORS errors:** Ensure `CORS_ORIGIN` matches your frontend URL.

---

## 8. Contributing

Pull requests are welcome! For major changes, please open an issue first to discuss what you would like to change.

---

## 9. License

MIT License
