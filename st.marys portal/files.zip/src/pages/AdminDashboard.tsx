import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminDashboard: React.FC = () => {
  const [students, setStudents] = useState<any[]>([]);
  const [selectedEmail, setSelectedEmail] = useState('');
  const [subjects, setSubjects] = useState([{subject: '', score: ''}]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchAll = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/results/all', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStudents(res.data);
    };
    fetchAll();
  }, []);

  const handleAddResult = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');
    const token = localStorage.getItem('token');
    try {
      await axios.post('http://localhost:5000/api/results/add', {
        email: selectedEmail,
        results: subjects.map(s => ({ subject: s.subject, score: Number(s.score) }))
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessage('Results updated!');
    } catch (error: any) {
      setMessage(error.response?.data?.error || 'Error adding results');
    }
  };

  return (
    <div className="container">
      <h2>Admin: Student Results Management</h2>
      <form onSubmit={handleAddResult}>
        <select required value={selectedEmail} onChange={e => setSelectedEmail(e.target.value)}>
          <option value="">Select Student</option>
          {students.map(s => <option key={s.email} value={s.email}>{s.name} ({s.email})</option>)}
        </select>
        {subjects.map((s, idx) => (
          <div key={idx}>
            <input
              type="text"
              placeholder="Subject"
              value={s.subject}
              onChange={e => {
                const next = [...subjects];
                next[idx].subject = e.target.value;
                setSubjects(next);
              }}
              required
            />
            <input
              type="number"
              placeholder="Score"
              value={s.score}
              onChange={e => {
                const next = [...subjects];
                next[idx].score = e.target.value;
                setSubjects(next);
              }}
              required
            />
          </div>
        ))}
        <button type="button" onClick={() => setSubjects([...subjects, {subject: '', score: ''}])}>Add Subject</button>
        <button type="submit">Save Results</button>
      </form>
      {message && <p>{message}</p>}
      <h3>All Students</h3>
      <ul>
        {students.map(s => (
          <li key={s.email}>
            {s.name} ({s.email})<br />
            Results: {s.results && s.results.length
              ? <ul>{s.results.map((r: any, i: number) =>
                  <li key={i}>{r.subject}: {r.score}</li>)}</ul>
              : 'No results'}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;