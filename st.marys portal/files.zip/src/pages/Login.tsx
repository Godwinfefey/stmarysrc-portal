import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

type Props = { setUser: (user: string) => void };

const Login: React.FC<Props> = ({ setUser }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr('');
    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', { email, password });
      localStorage.setItem('token', res.data.token);
      setUser(res.data.email);
      navigate('/results');
    } catch (err: any) {
      setErr(err.response?.data?.error || 'Login failed');
    }
  };

  return (
    <div className="container">
      <h2>Student Login</h2>
      <form onSubmit={handleLogin}>
        <input name="email" type="email" placeholder="Email" required value={email} onChange={e => setEmail(e.target.value)} />
        <input name="password" type="password" placeholder="Password" required value={password} onChange={e => setPassword(e.target.value)} />
        <button type="submit">Login</button>
      </form>
      {err && <p style={{color:'red'}}>{err}</p>}
    </div>
  );
};

export default Login;