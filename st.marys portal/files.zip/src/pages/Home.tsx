import React from 'react';

const Home: React.FC = () => (
  <div className="container">
    <h1>Welcome to St. Mary’s RC JHS Student Portal</h1>
    <p>
      Sign up to access your account and check your exam results online!
    </p>
  </div>
);

export default Home;