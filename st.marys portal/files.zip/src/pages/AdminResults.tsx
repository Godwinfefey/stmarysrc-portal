import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminResults: React.FC = () => {
  const [students, setStudents] = useState<any[]>([]);
  const [selectedEmail, setSelectedEmail] = useState('');
  const [subjects, setSubjects] = useState([{subject: '', score: ''}]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchAll = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/results/all', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStudents(res.data);
    };
    fetchAll();
  }, []);

  const handleAddResult = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    await axios.post('http://localhost:5000/api/results/add', {
      email: selectedEmail,
      results: subjects.map(s => ({ subject: s.subject, score: Number(s.score) }))
    }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setMessage('Results updated!');
  };

  return (
    <div className="container">
      <h2>Admin: Add/Update Student Results</h2>
      <form onSubmit={handleAddResult}>
        <select value={selectedEmail} onChange={e => setSelectedEmail(e.target.value)}>
          <option value="">Select Student</option>
          {students.map(s => <option key={s.email} value={s.email}>{s.name} ({s.email})</option>)}
        </select>
        {subjects.map((s, idx) => (
          <div key={idx}>
            <input
              type="text"
              placeholder="Subject"
              value={s.subject}
              onChange={e => {
                const next = [...subjects];
                next[idx].subject = e.target.value;
                setSubjects(next);
              }}
            />
            <input
              type="number"
              placeholder="Score"
              value={s.score}
              onChange={e => {
                const next = [...subjects];
                next[idx].score = e.target.value;
                setSubjects(next);
              }}
            />
          </div>
        ))}
        <button type="button" onClick={() => setSubjects([...subjects, {subject: '', score: ''}])}>Add Subject</button>
        <button type="submit">Save Results</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default AdminResults;