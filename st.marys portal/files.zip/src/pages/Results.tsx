import React, { useEffect, useState } from 'react';
import axios from 'axios';

type Props = {
  user: string;
};

type Result = {
  subject: string;
  score: number;
};

const Results: React.FC<Props> = ({ user }) => {
  const [results, setResults] = useState<Result[]>([]);

  useEffect(() => {
    const fetchResults = async () => {
      const token = localStorage.getItem('token');
      if (!token) return;
      const res = await axios.get('http://localhost:5000/api/results', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setResults(res.data);
    };
    fetchResults();
  }, []);

  return (
    <div className="container">
      <h2>Exam Results</h2>
      <p>Student: {user}</p>
      <table>
        <thead>
          <tr>
            <th>Subject</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {results.map(r => (
            <tr key={r.subject}>
              <td>{r.subject}</td>
              <td>{r.score}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Results;