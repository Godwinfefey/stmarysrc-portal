// ... (other imports)
import AdminDashboard from './pages/AdminDashboard';

// inside <Routes>
<Route path="/admin" element={<AdminDashboard />} />