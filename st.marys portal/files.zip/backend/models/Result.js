const mongoose = require('mongoose');

const ResultSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  results: [
    {
      subject: String,
      score: Number,
    }
  ],
});

module.exports = mongoose.model('Result', ResultSchema);