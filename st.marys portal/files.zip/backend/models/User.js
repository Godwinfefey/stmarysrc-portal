const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const UserSchema = new mongoose.Schema({
  // ... previous fields ...
  resetPasswordToken: String,
  resetPasswordExpires: Date,
});

// ... rest of schema ...