const nodemailer = require('nodemailer');
const crypto = require('crypto');

// ... existing code ...

// Password reset request
router.post('/request-password-reset', async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ error: 'User not found' });
  const token = crypto.randomBytes(20).toString('hex');
  user.resetPasswordToken = token;
  user.resetPasswordExpires = Date.now() + 3600000; // 1 hour
  await user.save();

  // Set up nodemailer transport (use your SMTP info)
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER, // in .env
      pass: process.env.EMAIL_PASS,
    },
  });

  const mailOptions = {
    to: user.email,
    from: process.env.EMAIL_USER,
    subject: 'St. Mary’s RC JHS - Password Reset',
    text: `Please reset your password by clicking the following link:\n\n` +
      `http://localhost:3000/reset-password/${token}\n\n` +
      `This link expires in 1 hour.`,
  };
  await transporter.sendMail(mailOptions);
  res.json({ message: 'Reset link sent to your email.' });
});

// Reset password handler
router.post('/reset-password/:token', async (req, res) => {
  const user = await User.findOne({
    resetPasswordToken: req.params.token,
    resetPasswordExpires: { $gt: Date.now() }
  });
  if (!user) return res.status(400).json({ error: 'Invalid or expired token' });
  user.password = req.body.password;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpires = undefined;
  await user.save();
  res.json({ message: 'Password reset successful!' });
});