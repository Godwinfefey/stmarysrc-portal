const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');

function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.userId;
    req.role = decoded.role;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

// Only admin
router.get('/users', auth, async (req, res) => {
  if (req.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  const users = await User.find().select('-password');
  res.json(users);
});

router.put('/disable/:userId', auth, async (req, res) => {
  if (req.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  await User.findByIdAndUpdate(req.params.userId, { disabled: true });
  res.json({ message: 'User disabled' });
});

router.put('/enable/:userId', auth, async (req, res) => {
  if (req.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  await User.findByIdAndUpdate(req.params.userId, { disabled: false });
  res.json({ message: 'User enabled' });
});

// Reset password for user
router.put('/reset-password/:userId', auth, async (req, res) => {
  if (req.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  const { password } = req.body;
  const user = await User.findById(req.params.userId);
  user.password = password;
  await user.save();
  res.json({ message: 'Password reset' });
});

module.exports = router;