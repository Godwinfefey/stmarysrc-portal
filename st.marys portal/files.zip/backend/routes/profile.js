const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');

function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.userId;
    req.role = decoded.role;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

router.get('/', auth, async (req, res) => {
  const user = await User.findById(req.userId).select('-password -resetPasswordToken -resetPasswordExpires');
  res.json(user);
});

router.put('/', auth, async (req, res) => {
  const { name } = req.body;
  await User.findByIdAndUpdate(req.userId, { name });
  res.json({ message: 'Profile updated' });
});

module.exports = router;