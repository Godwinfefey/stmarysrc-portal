// ...after saving results in /add route...
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const mailOptions = {
  to: student.email,
  from: process.env.EMAIL_USER,
  subject: 'St. Mary’s RC JHS - Exam Results Updated',
  text: `Dear ${student.name},\n\nYour exam results have been updated. Please log in to your account to view them.\n\nBest,\nSt. Mary’s RC JHS`,
};
await transporter.sendMail(mailOptions);