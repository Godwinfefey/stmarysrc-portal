import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/admin/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(res.data);
    };
    fetchUsers();
  }, []);

  const handleDisable = async (userId: string) => {
    const token = localStorage.getItem('token');
    await axios.put(`http://localhost:5000/api/admin/disable/${userId}`, {}, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setMsg('User disabled');
  };

  const handleEnable = async (userId: string) => {
    const token = localStorage.getItem('token');
    await axios.put(`http://localhost:5000/api/admin/enable/${userId}`, {}, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setMsg('User enabled');
  };

  // For password reset (admin sets new password)
  const handleResetPassword = async (userId: string) => {
    const token = localStorage.getItem('token');
    const newPassword = prompt('Enter new password:');
    if (!newPassword) return;
    await axios.put(`http://localhost:5000/api/admin/reset-password/${userId}`, { password: newPassword }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setMsg('Password reset');
  };

  return (
    <div className="container">
      <h2>Admin: User Management</h2>
      {users.map(u => (
        <div key={u._id}>
          <b>{u.name}</b> ({u.email}) - {u.role} {u.disabled ? "[DISABLED]" : ""}
          <button onClick={() => handleDisable(u._id)}>Disable</button>
          <button onClick={() => handleEnable(u._id)}>Enable</button>
          <button onClick={() => handleResetPassword(u._id)}>Reset Password</button>
        </div>
      ))}
      {msg && <p>{msg}</p>}
    </div>
  );
};

export default AdminUsers;