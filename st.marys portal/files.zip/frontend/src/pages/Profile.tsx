import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<any>({});
  const [name, setName] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/profile', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setProfile(res.data);
      setName(res.data.name);
    };
    fetchProfile();
  }, []);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    await axios.put('http://localhost:5000/api/profile', { name }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setMsg('Profile updated!');
  };

  return (
    <div className="container">
      <h2>Profile</h2>
      <form onSubmit={handleUpdate}>
        <input type="text" value={name} onChange={e => setName(e.target.value)} required />
        <button type="submit">Update</button>
      </form>
      {msg && <p>{msg}</p>}
      <p>Email: {profile.email}</p>
      <p>Role: {profile.role}</p>
    </div>
  );
};

export default Profile;