import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Signup from './pages/Signup';
import Login from './pages/Login';
import Results from './pages/Results';
import AdminDashboard from './pages/AdminDashboard';

const App: React.FC = () => {
  const [user, setUser] = useState<string | null>(null);
  const [role, setRole] = useState<string | null>(null);

  return (
    <Router>
      <nav className="navbar">
        <div className="nav-logo">St. Mary’s RC JHS</div>
        <ul>
          <li><Link to="/">Home</Link></li>
          <li><Link to="/signup">Sign Up</Link></li>
          <li><Link to="/login">Login</Link></li>
          {user && role === "student" && <li><Link to="/results">Results</Link></li>}
          {role === "admin" && <li><Link to="/admin">Admin</Link></li>}
        </ul>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login setUser={setUser} setRole={setRole} />} />
        <Route path="/results" element={user && role === "student" ? <Results user={user} /> : <Navigate to="/login" />} />
        <Route path="/admin" element={role === "admin" ? <AdminDashboard /> : <Navigate to="/login" />} />
      </Routes>
    </Router>
  );
};

export default App;